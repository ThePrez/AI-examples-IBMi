const bear = require('../app/models/bear');

const bb = new bear.Bear();

console.log(bb);
