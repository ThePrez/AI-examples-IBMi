# nodejs-db2-demo

This is a simple demo of Node.js Db2 connector and IBM i toolkit. 

You can copy the whole project into a directory named **mynodeapp**. The directory has following files --
```
mynodeapp
|-- index.js
|-- package.json
`-- public
    `-- sample.html
```

### Run the example

    cd mynodeapp
    npm i
    node index.js
    
Then browse http://yourip:8081/sample.html
