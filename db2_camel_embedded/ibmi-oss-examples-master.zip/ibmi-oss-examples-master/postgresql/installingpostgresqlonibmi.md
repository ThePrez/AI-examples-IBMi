# PostgreSQL Installation and Basic Configuration on IBM i

:rotating_light: The PostgreSQL install guide has been moved [here](https://ibmi-oss-docs.readthedocs.io/en/latest/postgresql.html) :rotating_light:
