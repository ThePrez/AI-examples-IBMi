#!/usr/bin/env bash

## install required deps
yum install python3-ibm_db
pip3 install -r requirements.txt

