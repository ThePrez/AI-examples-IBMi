import matplotlib.pyplot as plt
# Generate a plot and save it to matplot.png
plt.plot([1,2,3,4],[1,4,9,16])
plt.ylabel('some number')
plt.savefig('matplot')
